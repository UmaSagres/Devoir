﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bird2
{
    class Pigeon : Bird
    {
        public void PigeonTalk()
        {
            Console.WriteLine("Crroouuuu crroouuuuu");
        }
    }
}
