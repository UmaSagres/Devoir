﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bird2
{
    class Eagle : Bird
    {
        public void EagleTalk()
        {
            Console.WriteLine("Viva Benfica !!!");
        }
    }
}
