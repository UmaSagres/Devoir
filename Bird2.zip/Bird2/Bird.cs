﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bird2
{
    class Bird
    {
        public void DefaultTalk()
        {
            Console.WriteLine("Default bird sound");
        }
    }
}
